<?php

function redirect($link){
	?>
	<script>
	window.location.href = '<?php echo $link  ?>';
	</script>
	<?php
	die();
}

?>